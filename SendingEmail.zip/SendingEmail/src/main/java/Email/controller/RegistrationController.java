package Email.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Email.domain.User;
import Email.service.NotificationService;


@RestController
public class RegistrationController {
	
	private Logger logger = LoggerFactory.getLogger(RegistrationController.class);
	
	@Autowired
	private NotificationService notificationService;
	
	@RequestMapping("/signup")
	public String signup(){
		
		return "Please sign up for our service.";
		
	}
	
//	@Scheduled(fixedRate=5000)
//	public void reportCurrentTime(){
//		System.out.print("The time is now " + dateFormat.format(new Date()));
//		System.out.print("\n");
//	}
	
	//Send email every 1 minute or 60 seconds
	@Scheduled(fixedRate=60000)
	@RequestMapping("/signup-success")
	public String signupSuccess(){
		
		//create user
		User user = new User();
		user.setFirstName("Dan");
		user.setLastName("Vega");
		user.setEmailAddress("joeyayadc@gmail.com");
	
		
		
		//Send a notification
		try{
		
		notificationService.sendNotification(user);
	 }catch(MailException e){
		//Catch error 
		 
		 logger.info("Error Sending Email: " + e.getMessage());
	 }
//		System.out.print("The time is now " + dateFormat.format(new Date()));
//		System.out.print("\n");
		
		return "Thank you for registering with us.";
	}
}
