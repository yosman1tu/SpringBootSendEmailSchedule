package Email.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.SimpleMailMessage;



import Email.domain.User;


@Service
public class NotificationService {


	private JavaMailSender javaMailSender;
	
	@Autowired
	public NotificationService(JavaMailSender javaMailSender){
		this.javaMailSender = javaMailSender;
	}
	
	public void sendNotification(User user)
	{
	//Send Email
	
	SimpleMailMessage mail = new SimpleMailMessage();
	mail.setTo(user.getEmailAddress());
	mail.setFrom("joeyayadc@gmail.com");
	mail.setSubject("Toys for shots comming soon!");
	mail.setText("This is a cool email notification "
			+ "from Yahya Osman, thats whats up After one minute");
	
	javaMailSender.send(mail);
	
	}
}
